import pandas as pd
import numpy as np
import seaborn as sns
import warnings

from pandas import read_csv
from numpy import mean, std
from matplotlib import pyplot as plt
from matplotlib.pyplot import figure
from sklearn.feature_selection import VarianceThreshold
from sklearn.feature_selection import RFE, SelectKBest, f_classif
from sklearn.preprocessing import Normalizer
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier, AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import balanced_accuracy_score, make_scorer
from sklearn.model_selection import cross_val_score, RepeatedStratifiedKFold
from sklearn.model_selection import GridSearchCV, cross_validate
from sklearn.pipeline import Pipeline
from imblearn.over_sampling import RandomOverSampler, SMOTE, ADASYN, BorderlineSMOTE
from imblearn.combine import SMOTETomek, SMOTEENN
from imblearn.under_sampling import RandomUnderSampler, ClusterCentroids, NearMiss
from imblearn.under_sampling import RepeatedEditedNearestNeighbours, TomekLinks
from imblearn.pipeline import make_pipeline
from imblearn.metrics import specificity_score, sensitivity_score
from imblearn.ensemble import BalancedBaggingClassifier, BalancedRandomForestClassifier
from imblearn.ensemble import RUSBoostClassifier, EasyEnsembleClassifier
from xgboost import XGBClassifier

# ignore warnings
warnings.filterwarnings("ignore")

ROOT_DIRECTORY_RESULTS = "/Users/eirini/PycharmProjects/msc-data-science-project-2020_21---files-ezigou/results/"

FLAG_FEATURE_SELECTIONS = False
FLAG_SAMPLING = False
FLAG_ENSEMBLES = True


def balance_percentage(df_data_set, target):
    class_counts = df_data_set.groupby(target).size()
    balance_percent = (class_counts[1] / class_counts[0]) * 100
    print(class_counts)
    print("Balance percentage is: " + str(balance_percent)[0:4] + "%")
    df_data_set.hist(column='Bankrupt?')
    #plt.show()


def filter_constant_columns(df_data_set, variance=0):
    # This function filters out all the constant columns (variance = 0)

    constant_filter = VarianceThreshold(threshold=variance)
    constant_filter.fit(df_data_set)
    non_constant = constant_filter.get_support(indices=False)

    # print the name of the constant column
    names = {k: v for k, v in enumerate(df_data_set.columns)}
    print("Features with zero variance:")
    print([names[i] for i, f in enumerate(constant_filter.get_support()) if not f])

    # dataset transformation
    df_data_set = df_data_set[df_data_set.columns[non_constant]]

    return df_data_set


def calculate_correlations(df_data_set):
    # calculates the correlations between variables and exports them to csv file
    # exports to a csv file the maximum correlated features (above 0.8) and
    # to another csv their correlations
    # returns the correlation matrix of all the features (pandas dataFrame)

    # calculate all correlations
    correlations = df_data_set.corr(method='pearson')
    correlations = correlations.applymap(lambda x: round(float(x), 3))
    correlations.to_csv(ROOT_DIRECTORY_RESULTS +  "correlations.csv")

    # convert correlations dataframe to numpy array
    correlations_np = correlations.to_numpy()

    # find the correlated features (where |correlation| >= 0.65)
    correl_dict = {}
    dict_value = []
    max_correlations = np.zeros([95, 95])

    for i in range(0, len(correlations_np)):
        for j in range(0, len(correlations_np)):
            if i != j:
                if correlations_np[i, j] >= 0.65 or correlations_np[i, j] <= -0.65:
                    max_correlations[i, j] = correlations_np[i, j]
                    dict_value.append("X" + str(j))
        if dict_value != []:
            correl_dict["X" + str(i)] = dict_value
        dict_value = []

    # export the dictionary containing the correlated features to a csv file
    with open(ROOT_DIRECTORY_RESULTS + 'correlated_features.csv', 'w') as f:
        for key in correl_dict.keys():
            f.write("%s,%s\n" % (key, correl_dict[key]))

    # convert the matrix with the maximum correlations to a pdDataFrame
    max_correlations = pd.DataFrame(max_correlations, index=numbered_names, columns=numbered_names)
    max_correlations.to_csv(ROOT_DIRECTORY_RESULTS + "max_correlations_1.csv")

    # delete columns with all zeros
    max_correlations = filter_constant_columns(max_correlations)

    # delete rows with all zeros
    max_correlations = max_correlations.loc[(max_correlations != 0).any(axis=1)]

    # add correlation with itself (=1)
    identitity_matrix = np.identity(len(max_correlations))
    max_correlations = max_correlations + identitity_matrix

    # export maximum correlations to a csv file
    max_correlations.to_csv(ROOT_DIRECTORY_RESULTS +  "max_correlations_2.csv")

    print("The number of maximum correlated features is: ", max_correlations.shape[1])

    return correlations


def delete_correlated_features(correlation_matrix):
    # removes from the data the highly correlated features,
    # by keeping the feature with max correlation with target
    # returns the transformed dataset

    features_to_erase = set()
    correl_features = []
    correl_with_target = []

    for i in range(len(correlation_matrix.columns)):
        for j in range(i + 1):
            if abs(correlation_matrix.iloc[i, j]) >= 0.8:
                correl_features.append(correlation_matrix.columns[j])
                correl_with_target.append(abs(correlation_matrix.iloc[j, len(correlation_matrix) - 1]))

        max_corr = max(correl_with_target)
        first_max_value_index = correl_with_target.index(max_corr)
        correl_features.pop(first_max_value_index)
        for k in range(len(correl_features)):
            features_to_erase.add(correl_features[k])

        correl_features = []
        correl_with_target = []

    data.drop(labels=features_to_erase, axis=1, inplace=True)
    return data


# def correlation_plot(df_correlations):
#     # visualizes the results with a correlation matrix
#     # saves the plot to png file
#
#     # PLOT 1
#     fig = plt.figure(figsize=(20, 7))
#     ax = fig.add_subplot()
#     cax = ax.matshow(df_correlations, vmin=-1, vmax=1)
#     fig.colorbar(cax)
#     ticks = np.arange(0, len(df_correlations), 1)
#     ax.set_xticks = ticks
#     ax.set_yticks = ticks
#     ax.set_xticklabels(df_correlations.columns)
#     ax.set_yticklabels(df_correlations.columns)
#     plt.setp(ax.get_xticklabels(), rotation=60, ha="left", rotation_mode="anchor")
#     plt.show()
#     fig.savefig('Correlation Matrix Plot.png')
#
#     # PLOT 2 (seaborn)
#     sns_plt = plt.axes()
#     sns_plt = sns.heatmap(df_correlations, annot=False, cmap=plt.cm.Blues, ax=sns_plt)
#     sns_plt.set_title('Correlation Matrix Plot')


def calculate_skewness(df_data_set):
    skewness = data.skew()
    skewness = skewness.apply(lambda x: round(float(x), 2))
    skewness.to_csv(ROOT_DIRECTORY_RESULTS +  "skewness.csv")


def evaluate_model_rfe_2(model, x_input, y_output, k):
    # evaluate a given model for different number of features, selected by RFE
    # using cross-validation
    # (also prints out the selected features)

    results = []
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
    # define number of features to evaluate
    num_features = [i + 1 for i in range(k)]
    # enumerate each number of features
    for n in num_features:
        features_kept = rfe_elimination(model, x_input, y_output, n)
        # evaluate the model
        scores = cross_val_score(model, features_kept, y_output, scoring='balanced_accuracy', cv=cv, n_jobs=-1,
                                 error_score='raise')
        results.append(scores)
        # summarize the results
        # print('>%d %.3f (%.3f)' % (n, mean(scores), std(scores)))
        print('%.3f (%.3f)' % (mean(scores), std(scores)))


def rfe_elimination(model, x_input, y_output, n):
    # apply Recursive Feature Elimination(RFE) for feature selection
    # returns the dataset with the selected features normalized (without the target)

    rfe = RFE(model, n_features_to_select=n)
    fit = rfe.fit(x_input, y_output)
    # print("Num Features: %d" % fit.n_features_)
    # print("Selected Features: %s" % fit.support_)
    # print("Feature Ranking: %s" % fit.ranking_)

    df_scores = pd.DataFrame(fit.ranking_)
    df_columns = pd.DataFrame(x_input.columns)

    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)
    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']

    # find the columns of the best features
    featureScores = (featureScores.nsmallest(n, 'Score'))
    # print(featureScores)

    # plot the graph of feature importancies
    # ax = featureScores.plot.barh(x='Feature', y='Score', rot=0)

    # returned features data set
    col = featureScores['Feature']
    features = x_input[col]

    # normalise the returned features dataset
    features = normalize(features)

    return features


def rfe_feature_sequence(model, k):
    # prints the sequence of selected features according to a specified number (k)
    feature_sequence = []
    for n in range(1, k + 1):
        rfe_selected_features = rfe_elimination(model, x, y, n)
        feature_list = rfe_selected_features.columns
        # print(feature_list)
        for ele in feature_list:
            if ele not in feature_sequence:
                feature_sequence.append(ele)
        feature_list = []
    print(feature_sequence)


def evaluate_model_etc(model, x_input, y_output, k):
    # evaluate a given model for different number of features, selected by ETC
    # using cross-validation

    results = []
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
    # define number of features to evaluate
    num_features = [i + 1 for i in range(k)]
    # enumerate each number of features
    for n in num_features:
        features_kept = extra_trees_classifier(x_input, y_output, n)
        # evaluate the model
        scores = cross_val_score(model, features_kept, y_output,
                                 scoring='balanced_accuracy', cv=cv, n_jobs=-1, error_score='raise')
        results.append(scores)
        # summarize the results
        # print('>%d %.3f (%.3f)' % (n, mean(scores), std(scores)))
        print('%.3f (%.3f)' % (mean(scores), std(scores)))


def extra_trees_classifier(x_input, y_output, n):
    # feature selection with extra tree classifier - Feature Importance
    # returns the selected set of features (without the target), normalised
    # prints the plot of feature importances for number of features n=30
    model = ExtraTreesClassifier(random_state=21)
    tree = model.fit(x_input, y_output)

    df_scores = pd.DataFrame(tree.feature_importances_)
    df_columns = pd.DataFrame(x_input.columns)
    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)

    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']
    featureScores = featureScores.nlargest(n, 'Score')
    # print(featureScores)

    # plot and save the graph of feature importances
    # also save feature score table
    if n == 30:
        ax = featureScores.plot.barh(x='Feature', y='Score', rot=0)
        plt.savefig('feature_importances_ETC.png')
        featureScores.to_csv(ROOT_DIRECTORY_RESULTS +  "Feature_Scores_ETC.csv")

    # returned data set
    col = featureScores['Feature']
    features = x_input[col]
    features = normalize(features)

    return features


def evaluate_model_kbest(model, x_input, y_output, k):
    # evaluate a given model for different number of features, selected by Kbest
    # using k-fold cross-validation

    results = []
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
    # define number of features to evaluate
    num_features = [i + 1 for i in range(k)]
    # enumerate each number of features
    for n in num_features:
        features_kept = kbest(x_input, y_output, n)
        # evaluate the model
        scores = cross_val_score(model, features_kept, y_output,
                                 scoring='balanced_accuracy', cv=cv, n_jobs=-1, error_score='raise')
        results.append(scores)
        # summarize the results
        # print('>%d %.3f (%.3f)' % (n, mean(scores), std(scores)))
        print('%.3f (%.3f)' % (mean(scores), std(scores)))

        # plot model performance for comparison
    plt.boxplot(results, labels=num_features, showmeans=True)
    plt.show()


# def grid_search_bestk(model, x_input, y_output):
#     # apply a given model to find and return the preferable number of features
#     # uses grid search and cross validation
#
#     # define the pipeline to evaluate
#     bestfeatures = SelectKBest(score_func=f_classif)
#     pipeline = Pipeline(steps=[('anova', bestfeatures), ('mname', model)])
#     # define the grid
#     grid = dict()
#     grid['anova__k'] = [i + 1 for i in range(x_input.shape[1])]
#     # define the grid search
#     cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
#     # cv = KFold(n_splits=5, random_state=1, shuffle=True)
#     search = GridSearchCV(pipeline, grid, scoring='balanced_accuracy', n_jobs=-1, cv=cv)
#     # perform the search
#     results = search.fit(x_input, y_output)
#     # summarize best
#     print('Best Mean Accuracy: %.3f' % results.best_score_)
#     print('Best Config: %s' % results.best_params_)
#     k = ''.join(c for c in str(results.best_params_) if c in digits)
#
#     return int(k)


def kbest(x_input, y_output, n):
    # feature selection using K-best with anova f-test
    # returns the normalised dataset of n selected features

    # apply SelectKBest class to extract the top n best features
    bestfeatures = SelectKBest(score_func=f_classif, k=n)
    fit = bestfeatures.fit(x_input, y_output)
    df_scores = pd.DataFrame(fit.scores_)
    # df = pd.DataFrame(x_input)
    df_columns = pd.DataFrame(x_input.columns)

    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)
    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']

    # print best features
    # print(featureScores.nlargest(n,'Score'))

    # find the columns of the best features
    featureScores = featureScores.nlargest(n, 'Score')

    # print the features with descending feature importance, plot the graph
    if n == 30:
        # save selected features
        featureScores.to_csv(ROOT_DIRECTORY_RESULTS +  "Feature_Scores_kbest.csv")
        # plot the graph of feature importancies
        ax = featureScores.plot.barh(x='Feature', y='Score', rot=0)
        plt.savefig('feature_importancies_kbest.png')

    # returned data set
    col = featureScores['Feature']
    features = x_input[col]
    features = normalize(features)

    return features


def kbest_2(x_input, y_output, n):
    # feature selection using K-best with anova f-test
    # returns the dataset of n selected features (not normalised)

    # apply SelectKBest class to extract the top n best features
    bestfeatures = SelectKBest(score_func=f_classif, k=n)
    fit = bestfeatures.fit(x_input, y_output)
    df_scores = pd.DataFrame(fit.scores_)

    df_columns = pd.DataFrame(x_input.columns)

    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)
    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']

    # find the columns of the best features
    featureScores = featureScores.nlargest(n, 'Score')

    # returned data set
    col = featureScores['Feature']
    features = x_input[col]

    # print the selected features
    print("The selected features are: ")
    print(featureScores['Feature'])

    return features


def normalize(x_input):
    # Normalize the data

    scaler = Normalizer().fit(x_input)
    x_norm = scaler.transform(x_input)
    x_norm = pd.DataFrame(data=x_norm, columns=x_input.columns)

    return x_norm


def evaluate_models_imbalanced(given_list):
    # evaluates the ML models or ensemble models (depending on the given_list)
    # for imbalanced dataset of selected features
    # using k-fold cross validation and pipeline
    # stores scoring of each model to csv file

    results_bal_acc = []
    results_sensitivity = []
    results_specificity = []
    names = []
    mean_values = []

    for name, model in given_list:

        piped_model = make_pipeline(Normalizer(), model)
        cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=1)
        scores = cross_validate(piped_model, kbest_data_x, y, scoring=metrics_dict,
                                cv=cv, n_jobs=-1, error_score='raise', return_train_score=True)

        results_bal_acc.append(scores['test_balanced_accuracy'])
        results_sensitivity.append(scores['test_sensitivity'])
        results_specificity.append(scores['test_specificity'])
        names.append(name)

        mean_per_model = []

        for key in scores.keys():
            message = "%s - %s: %0.3f +/- %0.3f" % (name, key, scores[key].mean(), scores[key].std())
            print(message)
            # create a list that stores mean values per model
            mean_per_model.append(str(round(scores[key].mean(), 3)) + " +/- " + str(round(scores[key].std(), 3)))

        # create a list of lists that stores mean values per model for all models
        mean_values.append(mean_per_model)

    # store mean results for all models and save them in csv file
    mean_values = pd.DataFrame(mean_values).transpose()
    mean_values.columns = names
    mean_values.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                         "train spec"]
    if given_list == models_list:
        mean_values.to_csv(ROOT_DIRECTORY_RESULTS + "imbalanced_mean_values.csv")
    else:
        mean_values.to_csv(ROOT_DIRECTORY_RESULTS + "ensemble_mean_values.csv")

    # store results of every important metric for all models in DataFrame
    # and save them in csv file

    # testing balanced accuracy
    res_bal_acc = pd.DataFrame(results_bal_acc).transpose()
    res_bal_acc.columns = names
    if given_list == models_list:
        res_bal_acc.to_csv(ROOT_DIRECTORY_RESULTS + "imbalanced_scores_bal_acc.csv")
    else:
        res_bal_acc.to_csv(ROOT_DIRECTORY_RESULTS + "ensemble_scores_bal_acc.csv")

    # testing sensitivity
    res_sensitivity = pd.DataFrame(results_sensitivity).transpose()
    res_sensitivity.columns = names
    if given_list == models_list:
        res_sensitivity.to_csv(ROOT_DIRECTORY_RESULTS +  "imbalanced_scores_sensitivity.csv")
    else:
        res_sensitivity.to_csv(ROOT_DIRECTORY_RESULTS +  "ensemble_scores_sensitivity.csv")

    # testing specificity
    res_specificity = pd.DataFrame(results_specificity).transpose()
    res_specificity.columns = names
    if given_list == models_list:
        res_specificity.to_csv(ROOT_DIRECTORY_RESULTS +  "imbalanced_scores_specificity.csv")
    else:
        res_specificity.to_csv(ROOT_DIRECTORY_RESULTS +  "ensemble_scores_specificity.csv")


# evaluate_models_imbalanced(ensembles_list)

def evaluate_models_balanced():
    # evaluates the ML models for balanced datasets of selected features
    # using k-fold cross validation and pipeline
    # stores to csv the scoring of each sampling method and model and returns it

    results_bal_acc = []
    results_sensitivity = []
    results_specificity = []
    names = []
    mean_values = []

    for model_name, model in models_list:

        for sampling_name, method in sampling_list:
            piped_model = make_pipeline(Normalizer(), method, model)
            cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=1)
            scores = cross_validate(piped_model, kbest_data_x, y, scoring=metrics_dict,
                                    cv=cv, n_jobs=-1, error_score='raise', return_train_score=True)

            results_bal_acc.append(scores['test_balanced_accuracy'])
            results_sensitivity.append(scores['test_sensitivity'])
            results_specificity.append(scores['test_specificity'])
            names.append(model_name + "-" + sampling_name)
            mean_per_model = []

            for key in scores.keys():
                message = "%s / %s - %s: %0.3f +/- %0.3f" % (
                model_name, sampling_name, key, scores[key].mean(), scores[key].std())
                print(message)
                # create a list that stores mean values per model
                mean_per_model.append(str(round(scores[key].mean(), 3)) + " +/- " + str(round(scores[key].std(), 3)))

            # create a list of lists that stores mean values per model for all models
            mean_values.append(mean_per_model)

    # store mean results for all sampling method and models an save them in csv file
    mean_values = pd.DataFrame(mean_values).transpose()
    mean_values.columns = names
    mean_values.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                         "train spec"]
    mean_values.to_csv(ROOT_DIRECTORY_RESULTS +  "balanced_mean_values.csv")

    # store results of every metric for every sampling method and model
    # in DataFrame and save them in csv file
    res_bal_acc = pd.DataFrame(results_bal_acc).transpose()
    res_bal_acc.columns = names
    res_bal_acc.to_csv(ROOT_DIRECTORY_RESULTS +  "balanced_scores_bal_acc.csv")

    res_sensitivity = pd.DataFrame(results_sensitivity).transpose()
    res_sensitivity.columns = names
    res_sensitivity.to_csv(ROOT_DIRECTORY_RESULTS +  "balanced_scores_sensitivity.csv")

    res_specificity = pd.DataFrame(results_specificity).transpose()
    res_specificity.columns = names
    res_specificity.to_csv(ROOT_DIRECTORY_RESULTS +  "balanced_scores_specificity.csv")


# evaluate_models_balanced()

def make_boxplot(df):
    # accepts a dataframe and returns the boxplot by column
    # saves a png file named as the dataframe

    fig = plt.figure(figsize=(20, 7))
    fig.suptitle('Algorithm comparison')
    ax = fig.add_subplot(111)
    plt.boxplot(df, patch_artist=True, showmeans=True)
    ax.set_xticklabels(df.columns)
    ax.set_ylim(0, 1.1)
    ax.set_xlim(auto=True)
    name = [i for i in globals() if globals()[i] is df][0]
    plt.title(name)
    plt.savefig(ROOT_DIRECTORY_RESULTS + '%s.png' % name)


# def grid_search_neighbors():
#     neighbors = [x for x in range(1, 12)]
#     # neighbors=[12,22]
#
#     for ele in neighbors:
#         results = []
#         names = []
#         methods = [
#             # ('ADASYN', ADASYN(random_state=32, sampling_strategy='minority',n_jobs=-1, n_neighbors=ele)),
#             ('SMOTE', SMOTE(random_state=32, sampling_strategy='minority', n_jobs=-1, k_neighbors=ele))]
#
#         for sampling_name, method in methods:
#
#             for model_name, model in models_list:
#                 piped_model = make_pipeline(Normalizer(), method, model)
#                 cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=1)
#                 scores = cross_val_score(piped_model, kbest_data_x, y, scoring='balanced_accuracy',
#                                          cv=cv, n_jobs=-1, error_score='raise')
#                 results.append(scores)
#                 names.append(sampling_name + "-" + model_name)
#                 print("%d / %s / %s: %0.3f +/- %0.3f" % (ele, sampling_name, model_name, scores.mean(), scores.std()))


if __name__ == "__main__":
    """RUN"""
    
    """Data loading"""

    # load the csv data file (pandas dataframe)
    data = read_csv("/Users/eirini/PycharmProjects/msc-data-science-project-2020_21---files-ezigou/inputs/data.csv")
    print("original data shape: " + str(data.shape))

    # calculate balance percentage and visualise it
    balance_percentage(data, "Bankrupt?")

    # rearrange the data so target variable is in the last column
    cols = [col for col in data if col != data.columns[0]] + [data.columns[0]]
    data = data[cols]

    # delete constant columns
    data = filter_constant_columns(data)
    print("new data shape: " + str(data.shape))

    # rename columns for convenience

    # new names
    numbered_names = ["X" + str(i) for i in range(0, 95)]
    # create a dictionary that stores the matching
    attributes_matching = dict(zip(numbered_names, data.columns))
    # export the dictionary to a csv file
    with open(ROOT_DIRECTORY_RESULTS + 'numbered_names.csv', 'w') as f:
        for key in attributes_matching.keys():
            f.write("%s,%s\n" % (key, attributes_matching[key]))
    # rename the columns of the dataset
    data.columns = numbered_names

    """Descriptive Statistics"""

    # examine the data types
    data.dtypes.to_csv(ROOT_DIRECTORY_RESULTS + "types.csv")

    # variable description
    description = data.describe()
    description = description.applymap(lambda x: round(float(x), 3))
    description.to_csv(ROOT_DIRECTORY_RESULTS + "description.csv")
    print(description)

    # examine variable skewness
    calculate_skewness(data)

    """Handling with correlations"""

    # examine variable correlations
    print("From the maximum correlated features table")
    correlations = calculate_correlations(data)

    # visualise correlated features
    # correlation_plot(correlations)

    # remove from the data the highly correlated features (above 0.8)

    data = delete_correlated_features(correlations)
    print("Features kept to the dataset:")
    print(data.columns)
    print(data.shape)

    # save the transformed data to csv file
    data.to_csv(ROOT_DIRECTORY_RESULTS +  "uncorrelated_data.csv")
    # save to a txt file the features retained after removing the highly correlated
    uncorrelated = data.columns.to_list()
    with open(ROOT_DIRECTORY_RESULTS +  "uncorrelated_features.txt", 'w') as w_f:
        for element in uncorrelated:
            w_f.write(element + "\n")

    # split data to features (x) and target (y) dataframes
    x = data.drop(columns='X94')
    y = data['X94']

    if FLAG_FEATURE_SELECTIONS:
        """Feature Selection Processes"""
        
        """RFE"""

        print("RFE - LR:")
        evaluate_model_rfe_2(LogisticRegression(solver='liblinear'), x, y, 30)
        rfe_feature_sequence(LogisticRegression(solver='liblinear'), 30)

        print("RFE - CART:")
        evaluate_model_rfe_2(DecisionTreeClassifier(random_state=25), x, y, 30)
        rfe_feature_sequence(DecisionTreeClassifier(random_state=25), 30)

        print("RFE - RFC:")
        evaluate_model_rfe_2(RandomForestClassifier(random_state=25), x, y, 30)
        rfe_feature_sequence(RandomForestClassifier(random_state=25), 30)

        print("RFE - LnSVC:")
        evaluate_model_rfe_2(LinearSVC(), x, y, 30)
        rfe_feature_sequence(LinearSVC(), 30)

        """ETC"""

        print("ETC - LR:")
        evaluate_model_etc(LogisticRegression(solver='liblinear'), x, y, 30)
        print("ETC - CART:")
        evaluate_model_etc(DecisionTreeClassifier(random_state=25), x, y, 30)
        print("ETC - RFC:")
        evaluate_model_etc(RandomForestClassifier(random_state=25), x, y, 30)
        print("ETC - KNN:")
        evaluate_model_etc(KNeighborsClassifier(), x, y, 30)
        print("ETC - SVC:")
        evaluate_model_etc(SVC(), x, y, 30)
        print("ETC - LnSVC:")
        evaluate_model_etc(LinearSVC(), x, y, 30)

        """KBEST"""

        print("KBEST - LR:")
        evaluate_model_kbest(LogisticRegression(solver='liblinear'), x, y, 30)
        print("KBEST - CART:")
        evaluate_model_kbest(DecisionTreeClassifier(random_state=25), x, y, 30)
        print("KBEST - RFC:")
        evaluate_model_kbest(RandomForestClassifier(random_state=25), x, y, 30)
        print("KBEST - KNN:")
        evaluate_model_kbest(KNeighborsClassifier(), x, y, 30)
        print("KBEST - SVC:")
        evaluate_model_kbest(SVC(), x, y, 30)
        print("KBEST - LnSVC:")
        evaluate_model_kbest(LinearSVC(), x, y, 30)


    """FINAL DECISION ON FEATURE SELECTION"""

    # TRANSFORM THE DATASET WITH K-BEST METHOD
    # DECIDED NUMBER OF FEATURES EQUAL TO 4

    #kbest_norm_data_x = kbest(x, y, 4)  # normalised
    kbest_data_x = kbest_2(x, y, 4)  # not normalised


    """CREATION OF STUCTURES CONTAINING THE APPLIED ALGORITHMS/METHODOLOGIES"""

    # create a list (of tuples) of the ML models
    models_list = [('LR', LogisticRegression(solver='liblinear')),
                   ('CART', DecisionTreeClassifier(random_state=25)),
                   ('RFC', RandomForestClassifier(random_state=25)),
                   ('KNN', KNeighborsClassifier()),
                   ('SVC', SVC()),
                   ('LnSVC', LinearSVC())]

    # create a dictionary of evaluation metrics
    metrics_dict = {'balanced_accuracy': make_scorer(balanced_accuracy_score),
                    'sensitivity': make_scorer(sensitivity_score),
                    'specificity': make_scorer(specificity_score)}

    # create a list (of tuples) of sampling methods
    sampling_list = [('RanOver', RandomOverSampler(random_state=32, sampling_strategy='minority')),
                     ('ADASYN', ADASYN(random_state=32, sampling_strategy='minority', n_neighbors=5, n_jobs=-1)),
                     ('SMOTE', SMOTE(random_state=32, sampling_strategy='minority', k_neighbors=5, n_jobs=-1)),
                     ('BLSmote', BorderlineSMOTE(random_state=32, sampling_strategy='minority', k_neighbors=5,
                                                 m_neighbors=10, kind='borderline-1', n_jobs=-1)),
                     ('SmoteTom', SMOTETomek(random_state=32, sampling_strategy='minority', n_jobs=-1)),
                     ('SmoteENN', SMOTEENN(random_state=32, sampling_strategy='minority', n_jobs=-1)),
                     ('RanUnder', RandomUnderSampler(random_state=32, sampling_strategy='majority', replacement=False)),
                     ('ClustCen', ClusterCentroids(random_state=32, sampling_strategy='majority', n_jobs=-1)),
                     ('NearMiss', NearMiss(version=3, sampling_strategy='majority', n_jobs=-1)),
                     ('TomLinks', TomekLinks(sampling_strategy='majority', n_jobs=-1)),
                     ('RepENN', RepeatedEditedNearestNeighbours(sampling_strategy='majority', n_jobs=-1))
                     ]

    # create a list of tuples of ensembles methods:
    ensembles_list = [
        ('RFbw', RandomForestClassifier(random_state=25, n_estimators=100, class_weight='balanced_subsample', n_jobs=-1)),
        ('AdaBoost', AdaBoostClassifier(base_estimator=DecisionTreeClassifier(random_state=25), random_state=66,
                                        n_estimators=100)),
        ('GB', GradientBoostingClassifier(random_state=66, n_estimators=100, loss='deviance')),
        ('XGB', XGBClassifier(random_state=66, scale_pos_weights=30, n_estimators=100, n_jobs=-1, verbosity=0)),
        ('BB', BalancedBaggingClassifier(base_estimator=DecisionTreeClassifier(random_state=25),
                                         random_state=66, n_estimators=100, n_jobs=-1)),
        ('BBada', BalancedBaggingClassifier(base_estimator=AdaBoostClassifier(),
                                            random_state=66, n_estimators=100, n_jobs=-1)),
        ('BRF', BalancedRandomForestClassifier(random_state=66, n_estimators=100, replacement=True, n_jobs=-1)),
        ('RUSBoost', RUSBoostClassifier(base_estimator=AdaBoostClassifier(), random_state=66, n_estimators=100, replacement=False)),
        ('EE', EasyEnsembleClassifier(random_state=66, n_estimators=100, n_jobs=-1))
    ]


    if FLAG_SAMPLING:
        """APPLYING SAMPLING METHODS"""

        # evaluate the ML models for imbalanced and normalized selected features
        evaluate_models_imbalanced(models_list)

        # evaluate the ML models on balanced and normalized selected features
        evaluate_models_balanced()

        # Create tables of mean values and standard deviations of evaluation metrics
        # for every sampling method used (or none) for each model

        imbalanced_mean_values = read_csv(ROOT_DIRECTORY_RESULTS + "imbalanced_mean_values.csv")
        balanced_mean_values = read_csv(ROOT_DIRECTORY_RESULTS + "balanced_mean_values.csv")

        # create new dataframes of mean values and standard deviations of evaluation metrics
        # per ML model for every sampling method (and none)

        matrix_LR = pd.concat([imbalanced_mean_values["LR"], balanced_mean_values.iloc[:, 1:12]], axis=1)
        matrix_CART = pd.concat([imbalanced_mean_values["CART"], balanced_mean_values.iloc[:, 12:23]], axis=1)
        matrix_RFC = pd.concat([imbalanced_mean_values["RFC"], balanced_mean_values.iloc[:, 23:34]], axis=1)
        matrix_KNN = pd.concat([imbalanced_mean_values["KNN"], balanced_mean_values.iloc[:, 34:45]], axis=1)
        matrix_SVC = pd.concat([imbalanced_mean_values["SVC"], balanced_mean_values.iloc[:, 45:56]], axis=1)
        matrix_LnSVC = pd.concat([imbalanced_mean_values["LnSVC"], balanced_mean_values.iloc[:, 56:67]], axis=1)

        matrix_LR.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                           "train spec"]
        matrix_CART.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                             "train spec"]
        matrix_RFC.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                            "train spec"]
        matrix_KNN.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                            "train spec"]
        matrix_SVC.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                            "train spec"]
        matrix_LnSVC.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                              "train spec"]

        # store to csv
        matrix_LR.to_csv(ROOT_DIRECTORY_RESULTS +  "matrix_LR.csv")
        matrix_CART.to_csv(ROOT_DIRECTORY_RESULTS +  "matrix_CART.csv")
        matrix_RFC.to_csv(ROOT_DIRECTORY_RESULTS +  "matrix_RFC.csv")
        matrix_KNN.to_csv(ROOT_DIRECTORY_RESULTS +  "matrix_KNN.csv")
        matrix_SVC.to_csv(ROOT_DIRECTORY_RESULTS +  "matrix_SVC.csv")
        matrix_LnSVC.to_csv(ROOT_DIRECTORY_RESULTS +  "matrix_LnSVC.csv")

        # Make dataframes to create boxplots for every sampling method used (or none) for each model

        # load and read the files that store the metrics
        bal_acc_1 = read_csv(ROOT_DIRECTORY_RESULTS + "imbalanced_scores_bal_acc.csv")
        bal_acc_1 = bal_acc_1.drop(['Unnamed: 0'], axis=1)
        bal_acc_2 = read_csv(ROOT_DIRECTORY_RESULTS + "balanced_scores_bal_acc.csv")

        sensitivity_1 = read_csv(ROOT_DIRECTORY_RESULTS + "imbalanced_scores_sensitivity.csv")
        sensitivity_1 = sensitivity_1.drop(['Unnamed: 0'], axis=1)
        sensitivity_2 = read_csv(ROOT_DIRECTORY_RESULTS + "balanced_scores_sensitivity.csv")

        specificity_1 = read_csv(ROOT_DIRECTORY_RESULTS + "imbalanced_scores_specificity.csv")
        specificity_1 = specificity_1.drop(['Unnamed: 0'], axis=1)
        specificity_2 = read_csv(ROOT_DIRECTORY_RESULTS + "balanced_scores_specificity.csv")

        # create new dataframes of evaluation metrics per ML model
        # for every sampling method (and none)

        # balanced accuracy
        acc_matrix_LR = pd.concat([bal_acc_1["LR"], bal_acc_2.iloc[:, 1:12]], axis=1)
        acc_matrix_CART = pd.concat([bal_acc_1["CART"], bal_acc_2.iloc[:, 12:23]], axis=1)
        acc_matrix_RFC = pd.concat([bal_acc_1["RFC"], bal_acc_2.iloc[:, 23:34]], axis=1)
        acc_matrix_KNN = pd.concat([bal_acc_1["KNN"], bal_acc_2.iloc[:, 34:45]], axis=1)
        acc_matrix_SVC = pd.concat([bal_acc_1["SVC"], bal_acc_2.iloc[:, 45:56]], axis=1)
        acc_matrix_LnSVC = pd.concat([bal_acc_1["LnSVC"], bal_acc_2.iloc[:, 56:67]], axis=1)

        # sensitivity
        sensitivity_matrix_LR = pd.concat([sensitivity_1["LR"], sensitivity_2.iloc[:, 1:12]], axis=1)
        sensitivity_matrix_CART = pd.concat([sensitivity_1["CART"], sensitivity_2.iloc[:, 12:23]], axis=1)
        sensitivity_matrix_RFC = pd.concat([sensitivity_1["RFC"], sensitivity_2.iloc[:, 23:34]], axis=1)
        sensitivity_matrix_KNN = pd.concat([sensitivity_1["KNN"], sensitivity_2.iloc[:, 34:45]], axis=1)
        sensitivity_matrix_SVC = pd.concat([sensitivity_1["SVC"], sensitivity_2.iloc[:, 45:56]], axis=1)
        sensitivity_matrix_LnSVC = pd.concat([sensitivity_1["LnSVC"], sensitivity_2.iloc[:, 56:67]], axis=1)

        # specificity
        specificity_matrix_LR = pd.concat([specificity_1["LR"], specificity_2.iloc[:, 1:12]], axis=1)
        specificity_matrix_CART = pd.concat([specificity_1["CART"], specificity_2.iloc[:, 12:23]], axis=1)
        specificity_matrix_RFC = pd.concat([specificity_1["RFC"], specificity_2.iloc[:, 23:34]], axis=1)
        specificity_matrix_KNN = pd.concat([specificity_1["KNN"], specificity_2.iloc[:, 34:45]], axis=1)
        specificity_matrix_SVC = pd.concat([specificity_1["SVC"], specificity_2.iloc[:, 45:56]], axis=1)
        specificity_matrix_LnSVC = pd.concat([specificity_1["LnSVC"], specificity_2.iloc[:, 56:67]], axis=1)

        # make and store the boxplots to evaluate classification models and sampling methods

        # make a list of the matrices that will be used for boxploting
        boxplot_list = [bal_acc_1, sensitivity_1, specificity_1, acc_matrix_LR, acc_matrix_CART, acc_matrix_RFC,
                        acc_matrix_KNN, acc_matrix_SVC, acc_matrix_LnSVC, sensitivity_matrix_LR, sensitivity_matrix_CART,
                        sensitivity_matrix_RFC, sensitivity_matrix_KNN, sensitivity_matrix_SVC, sensitivity_matrix_LnSVC,
                        specificity_matrix_LR, specificity_matrix_CART, specificity_matrix_RFC, specificity_matrix_KNN,
                        specificity_matrix_SVC, specificity_matrix_LnSVC]

        for matrix in boxplot_list:
            make_boxplot(matrix)

    if FLAG_ENSEMBLES:

        """APPLYING ENSEMBLE MODELS"""

        # evaluate ensemble models for imbalanced and normalized selected features
        evaluate_models_imbalanced(ensembles_list)

        # Make dataframes to create boxplots for every ensemble model

        # load and read the files that store the metrics
        bal_acc_ens = read_csv(ROOT_DIRECTORY_RESULTS + "ensemble_scores_bal_acc.csv")
        bal_acc_ens = bal_acc_ens.drop(['Unnamed: 0'], axis=1)

        sensitivity_ens = read_csv(ROOT_DIRECTORY_RESULTS + "ensemble_scores_sensitivity.csv")
        sensitivity_ens = sensitivity_ens.drop(['Unnamed: 0'], axis=1)

        specificity_ens = read_csv(ROOT_DIRECTORY_RESULTS + "ensemble_scores_specificity.csv")
        specificity_ens = specificity_ens.drop(['Unnamed: 0'], axis=1)

        # make and store the boxplots to evaluate ensemble models

        # make a list of the matrices that will be used for boxploting
        boxplot_list_ens = [bal_acc_ens, sensitivity_ens, specificity_ens]

        for metric in boxplot_list_ens:
            make_boxplot(metric)
