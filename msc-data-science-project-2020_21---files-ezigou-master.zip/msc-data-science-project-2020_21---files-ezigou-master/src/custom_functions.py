import pandas as pd
import numpy as np

from numpy import mean, std
from matplotlib import pyplot as plt

from sklearn.feature_selection import VarianceThreshold
from sklearn.feature_selection import RFE, SelectKBest, f_classif
from sklearn.preprocessing import Normalizer
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.model_selection import cross_val_score, RepeatedStratifiedKFold, cross_validate
from sklearn.linear_model import LogisticRegression

from imblearn.pipeline import make_pipeline


def balance_percentage(df_data_set, target, root_directory_results):
    class_counts = df_data_set.groupby(target).size()
    balance_percent = (class_counts[1] / class_counts[0]) * 100
    print(class_counts)
    print("Balance percentage is: " + str(balance_percent)[0:4] + "%")

    df_data_set.hist(column='Bankrupt?')
    plt.suptitle("Balance examination")
    plt.savefig(root_directory_results + "balance_percentage.png")


def filter_constant_columns(df_data_set, variance=0):
    # This function filters out all the constant columns (variance = 0)

    constant_filter = VarianceThreshold(threshold=variance)
    constant_filter.fit(df_data_set)
    non_constant = constant_filter.get_support(indices=False)

    # print the name of the constant column
    names = {k: v for k, v in enumerate(df_data_set.columns)}
    print("Features with zero variance:")
    print([names[i] for i, f in enumerate(constant_filter.get_support()) if not f])

    # data set transformation
    df_data_set = df_data_set[df_data_set.columns[non_constant]]

    return df_data_set


def calculate_correlations(df_data_set, root_directory_results, numbered_names):
    # calculates the correlations between variables and exports them to csv file
    # exports to a csv file the maximum correlated features (above 0.8) and
    # to another csv their correlations
    # returns the correlation matrix of all the features (pandas dataFrame)

    # calculate all correlations
    correlations = df_data_set.corr(method='pearson')
    correlations = correlations.applymap(lambda x: round(float(x), 3))
    correlations.to_csv(root_directory_results + "correlations.csv")

    # convert correlations dataframe to numpy array
    correlations_np = correlations.to_numpy()

    # find the correlated features (where |correlation| >= 0.65)
    correl_dict = {}
    dict_value = []
    max_correlations = np.zeros([95, 95])

    for i in range(0, len(correlations_np)):
        for j in range(0, len(correlations_np)):
            if i != j:
                if correlations_np[i, j] >= 0.65 or correlations_np[i, j] <= -0.65:
                    max_correlations[i, j] = correlations_np[i, j]
                    dict_value.append("X" + str(j))
        if dict_value != []:
            correl_dict["X" + str(i)] = dict_value
        dict_value = []

    # export the dictionary containing the correlated features to a csv file
    with open(root_directory_results + 'correlated_features.csv', 'w') as f:
        for key in correl_dict.keys():
            f.write("%s,%s\n" % (key, correl_dict[key]))

    # convert the matrix with the maximum correlations to a pdDataFrame
    max_correlations = pd.DataFrame(max_correlations, index=numbered_names, columns=numbered_names)
    max_correlations.to_csv(root_directory_results + "max_correlations_1.csv")

    # delete columns with all zeros
    max_correlations = filter_constant_columns(max_correlations)

    # delete rows with all zeros
    max_correlations = max_correlations.loc[(max_correlations != 0).any(axis=1)]

    # add correlation with itself (=1)
    identity_matrix = np.identity(len(max_correlations))
    max_correlations = max_correlations + identity_matrix

    # export maximum correlations to a csv file
    max_correlations.to_csv(root_directory_results + "max_correlations_2.csv")

    print("The number of maximum correlated features is: ", max_correlations.shape[1])

    return correlations


def delete_correlated_features(correlation_matrix, data):
    # removes from the data the highly correlated features,
    # by keeping the feature with max correlation with target
    # returns the transformed dataset

    features_to_erase = set()
    correl_features = []
    correl_with_target = []

    for i in range(len(correlation_matrix.columns)):
        for j in range(i + 1):
            if abs(correlation_matrix.iloc[i, j]) >= 0.8:
                correl_features.append(correlation_matrix.columns[j])
                correl_with_target.append(abs(correlation_matrix.iloc[j, len(correlation_matrix) - 1]))

        max_corr = max(correl_with_target)
        first_max_value_index = correl_with_target.index(max_corr)
        correl_features.pop(first_max_value_index)
        for k in range(len(correl_features)):
            features_to_erase.add(correl_features[k])

        correl_features = []
        correl_with_target = []

    data.drop(labels=features_to_erase, axis=1, inplace=True)

    return data


def calculate_skewness(df_data_set, root_directory_results):
    skewness = df_data_set.skew()
    skewness = skewness.apply(lambda x: round(float(x), 2))
    skewness.to_csv(root_directory_results + "skewness.csv")


def evaluate_model_rfe(model, x_input, y_output, k):
    # evaluate a given model for different number of features, selected by RFE
    # using cross-validation
    # (also prints out the selected features)

    results = []
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
    # define number of features to evaluate
    num_features = [i + 1 for i in range(k)]
    # enumerate each number of features
    for n in num_features:
        features_kept = rfe_elimination(model, x_input, y_output, n)
        # evaluate the model
        scores = cross_val_score(model, features_kept, y_output, scoring='balanced_accuracy', cv=cv, n_jobs=-1,
                                 error_score='raise')
        results.append(scores)
        # summarize the results
        # print('>%d %.3f (%.3f)' % (n, mean(scores), std(scores)))
        print('%.3f (%.3f)' % (mean(scores), std(scores)))


def rfe_elimination(model, x_input, y_output, n):
    # apply Recursive Feature Elimination(RFE) for feature selection
    # returns the dataset with the selected features normalized (without the target)

    rfe = RFE(model, n_features_to_select=n)
    fit = rfe.fit(x_input, y_output)
    # print("Num Features: %d" % fit.n_features_)
    # print("Selected Features: %s" % fit.support_)
    # print("Feature Ranking: %s" % fit.ranking_)

    df_scores = pd.DataFrame(fit.ranking_)
    df_columns = pd.DataFrame(x_input.columns)

    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)
    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']

    # get the sequence that the features are selected in order of descending importance
    if n == 1:
        featureScores.sort_values(by='Score', inplace=True)
        featureScores = featureScores.nsmallest(30, 'Score')
        print(featureScores['Feature'].to_list())

    # find the columns of the best features
    featureScores = featureScores.nsmallest(n, 'Score')
    # print(featureScores)

    # returned features data set
    col = featureScores['Feature']
    features = x_input[col]

    # normalise the returned features dataset
    features = normalize(features)

    return features


def evaluate_model_etc(model, x_input, y_output, k, root_directory_results):
    # evaluate a given model for different number of features, selected by ETC
    # using cross-validation

    results = []
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
    # define number of features to evaluate
    num_features = [i + 1 for i in range(k)]
    # enumerate each number of features
    for n in num_features:
        features_kept = extra_trees_classifier(model, x_input, y_output, n, root_directory_results)
        # evaluate the model
        scores = cross_val_score(model, features_kept, y_output,
                                 scoring='balanced_accuracy', cv=cv, n_jobs=-1, error_score='raise')
        results.append(scores)
        # summarize the results
        # print('>%d %.3f (%.3f)' % (n, mean(scores), std(scores)))
        print('%.3f (%.3f)' % (mean(scores), std(scores)))


def extra_trees_classifier(model, x_input, y_output, n, root_directory_results):
    # feature selection with extra tree classifier - Feature Importance
    # returns the selected set of features (without the target), normalised
    # prints the plot of feature importance for number of features n=30

    model_etc = ExtraTreesClassifier(random_state=21)
    tree = model_etc.fit(x_input, y_output)

    df_scores = pd.DataFrame(tree.feature_importances_)
    df_columns = pd.DataFrame(x_input.columns)
    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)

    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']
    featureScores = featureScores.nlargest(n, 'Score')
    # print(featureScores)

    # plot and save the graph of feature importance and
    # also save feature score table
    # and do it only once for top 30 predictors
    if n == 30 and isinstance(model, LogisticRegression):
        featureScores.plot.barh(x='Feature', y='Score', rot=0)
        plt.suptitle("Feature Scores by ETC")
        plt.savefig(root_directory_results + 'feature_importances_ETC.png')
        featureScores.to_csv(root_directory_results + "Feature_Scores_ETC.csv")

    # returned data set
    col = featureScores['Feature']
    features = x_input[col]
    features = normalize(features)

    return features


def evaluate_model_kbest(model, x_input, y_output, k, root_directory_results):
    # evaluate a given model for different number of features, selected by Kbest
    # using k-fold cross-validation

    results = []
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
    # define number of features to evaluate
    num_features = [i + 1 for i in range(k)]
    # enumerate each number of features
    for n in num_features:
        features_kept = kbest(model, x_input, y_output, n, root_directory_results)
        # evaluate the model
        scores = cross_val_score(model, features_kept, y_output,
                                 scoring='balanced_accuracy', cv=cv, n_jobs=-1, error_score='raise')
        results.append(scores)
        # summarize the results
        # print('>%d %.3f (%.3f)' % (n, mean(scores), std(scores)))
        print('%.3f (%.3f)' % (mean(scores), std(scores)))

    # # plot each model performance for every n
    # plt.boxplot(results, labels=num_features, showmeans=True)
    # plt.show()


# def grid_search_bestk(model, x_input, y_output):
#     # apply a given model to find and return the preferable number of features
#     # uses grid search and cross validation
#
#     # define the pipeline to evaluate
#     bestfeatures = SelectKBest(score_func=f_classif)
#     pipeline = Pipeline(steps=[('anova', bestfeatures), ('mname', model)])
#     # define the grid
#     grid = dict()
#     grid['anova__k'] = [i + 1 for i in range(x_input.shape[1])]
#     # define the grid search
#     cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=1, random_state=1)
#     # cv = KFold(n_splits=5, random_state=1, shuffle=True)
#     search = GridSearchCV(pipeline, grid, scoring='balanced_accuracy', n_jobs=-1, cv=cv)
#     # perform the search
#     results = search.fit(x_input, y_output)
#     # summarize best
#     print('Best Mean Accuracy: %.3f' % results.best_score_)
#     print('Best Config: %s' % results.best_params_)
#     k = ''.join(c for c in str(results.best_params_) if c in digits)
#
#     return int(k)


def kbest(model, x_input, y_output, n, root_directory_results):
    # feature selection using K-best with anova f-test
    # returns the normalised dataset of n selected features

    # apply SelectKBest class to extract the top n best features
    bestfeatures = SelectKBest(score_func=f_classif, k=n)
    fit = bestfeatures.fit(x_input, y_output)
    df_scores = pd.DataFrame(fit.scores_)
    # df = pd.DataFrame(x_input)
    df_columns = pd.DataFrame(x_input.columns)

    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)
    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']

    # print best features
    # print(featureScores.nlargest(n,'Score'))

    # find the columns of the best features
    featureScores = featureScores.nlargest(n, 'Score')

    # plot and save the graph of feature importance and
    # also save feature score table
    # and do it only once for top 30 predictors
    if n == 30 and isinstance(model, LogisticRegression):
        featureScores.to_csv(root_directory_results + "Feature_Scores_kbest.csv")
        featureScores.plot.barh(x='Feature', y='Score', rot=0)
        plt.suptitle("Feature Scores by K-BEST")
        plt.savefig(root_directory_results + 'feature_importances_kbest.png')

    # returned data set
    col = featureScores['Feature']
    features = x_input[col]
    features = normalize(features)

    return features


def kbest_2(x_input, y_output, n):
    # feature selection using K-best with anova f-test
    # returns the dataset of n selected features (not normalised)

    # apply SelectKBest class to extract the top n best features
    bestfeatures = SelectKBest(score_func=f_classif, k=n)
    fit = bestfeatures.fit(x_input, y_output)
    df_scores = pd.DataFrame(fit.scores_)

    df_columns = pd.DataFrame(x_input.columns)

    # concat two dataframes for better visualization
    featureScores = pd.concat([df_columns, df_scores], axis=1)
    # naming the dataframe columns
    featureScores.columns = ['Feature', 'Score']

    # find the columns of the best features
    featureScores = featureScores.nlargest(n, 'Score')

    # returned data set
    col = featureScores['Feature']
    features = x_input[col]

    # print the selected features
    print("The selected features are: ")
    print(featureScores['Feature'])

    return features


def normalize(x_input):
    # Normalize the data

    scaler = Normalizer().fit(x_input)
    x_norm = scaler.transform(x_input)
    x_norm = pd.DataFrame(data=x_norm, columns=x_input.columns)

    return x_norm


def evaluate_models_imbalanced(given_list, models_list, root_directory_results, metrics_dict, kbest_data_x, y):
    # evaluates the ML models or ensemble models (depending on the given_list)
    # for imbalanced dataset of selected features
    # using k-fold cross validation and pipeline
    # stores scoring of each model to csv file

    results_bal_acc = []
    results_sensitivity = []
    results_specificity = []
    names = []
    mean_values = []

    for name, model in given_list:

        piped_model = make_pipeline(Normalizer(), model)
        cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=1)
        scores = cross_validate(piped_model, kbest_data_x, y, scoring=metrics_dict,
                                cv=cv, n_jobs=-1, error_score='raise', return_train_score=True)

        results_bal_acc.append(scores['test_balanced_accuracy'])
        results_sensitivity.append(scores['test_sensitivity'])
        results_specificity.append(scores['test_specificity'])
        names.append(name)

        mean_per_model = []

        for key in scores.keys():
            message = "%s - %s: %0.3f +/- %0.3f" % (name, key, scores[key].mean(), scores[key].std())
            print(message)
            # create a list that stores mean values per model
            mean_per_model.append(str(round(scores[key].mean(), 3)) + " +/- " + str(round(scores[key].std(), 3)))

        # create a list of lists that stores mean values per model for all models
        mean_values.append(mean_per_model)

    # store mean results for all models and save them in csv file
    mean_values = pd.DataFrame(mean_values).transpose()
    mean_values.columns = names
    mean_values.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                         "train spec"]
    if given_list == models_list:
        mean_values.to_csv(root_directory_results + "imbalanced_mean_values.csv")
    else:
        mean_values.to_csv(root_directory_results + "ensemble_mean_values.csv")

    # store results of every important metric for all models in DataFrame
    # and save them in csv file

    # testing balanced accuracy
    res_bal_acc = pd.DataFrame(results_bal_acc).transpose()
    res_bal_acc.columns = names
    if given_list == models_list:
        res_bal_acc.to_csv(root_directory_results + "imbalanced_scores_bal_acc.csv")
    else:
        res_bal_acc.to_csv(root_directory_results + "ensemble_scores_bal_acc.csv")

    # testing sensitivity
    res_sensitivity = pd.DataFrame(results_sensitivity).transpose()
    res_sensitivity.columns = names
    if given_list == models_list:
        res_sensitivity.to_csv(root_directory_results + "imbalanced_scores_sensitivity.csv")
    else:
        res_sensitivity.to_csv(root_directory_results + "ensemble_scores_sensitivity.csv")

    # testing specificity
    res_specificity = pd.DataFrame(results_specificity).transpose()
    res_specificity.columns = names
    if given_list == models_list:
        res_specificity.to_csv(root_directory_results + "imbalanced_scores_specificity.csv")
    else:
        res_specificity.to_csv(root_directory_results + "ensemble_scores_specificity.csv")


# evaluate_models_imbalanced(ensembles_list)

def evaluate_models_balanced(models_list, sampling_list, root_directory_results, kbest_data_x, y, metrics_dict):
    # evaluates the ML models for balanced datasets of selected features
    # using k-fold cross validation and pipeline
    # stores to csv the scoring of each sampling method and model and returns it

    results_bal_acc = []
    results_sensitivity = []
    results_specificity = []
    names = []
    mean_values = []

    for model_name, model in models_list:

        for sampling_name, method in sampling_list:
            piped_model = make_pipeline(Normalizer(), method, model)
            cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=1)
            scores = cross_validate(piped_model, kbest_data_x, y, scoring=metrics_dict,
                                    cv=cv, n_jobs=-1, error_score='raise', return_train_score=True)

            results_bal_acc.append(scores['test_balanced_accuracy'])
            results_sensitivity.append(scores['test_sensitivity'])
            results_specificity.append(scores['test_specificity'])
            names.append(model_name + "-" + sampling_name)
            mean_per_model = []

            for key in scores.keys():
                message = "%s / %s - %s: %0.3f +/- %0.3f" % (
                model_name, sampling_name, key, scores[key].mean(), scores[key].std())
                print(message)
                # create a list that stores mean values per model
                mean_per_model.append(str(round(scores[key].mean(), 3)) + " +/- " + str(round(scores[key].std(), 3)))

            # create a list of lists that stores mean values per model for all models
            mean_values.append(mean_per_model)

    # store mean results for all sampling method and models an save them in csv file
    mean_values = pd.DataFrame(mean_values).transpose()
    mean_values.columns = names
    mean_values.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                         "train spec"]
    mean_values.to_csv(root_directory_results + "balanced_mean_values.csv")

    # store results of every metric for every sampling method and model
    # in DataFrame and save them in csv file
    res_bal_acc = pd.DataFrame(results_bal_acc).transpose()
    res_bal_acc.columns = names
    res_bal_acc.to_csv(root_directory_results + "balanced_scores_bal_acc.csv")

    res_sensitivity = pd.DataFrame(results_sensitivity).transpose()
    res_sensitivity.columns = names
    res_sensitivity.to_csv(root_directory_results + "balanced_scores_sensitivity.csv")

    res_specificity = pd.DataFrame(results_specificity).transpose()
    res_specificity.columns = names
    res_specificity.to_csv(root_directory_results + "balanced_scores_specificity.csv")


# evaluate_models_balanced()

def helper_name_str(obj, namespace):
    return [name for name in namespace if namespace[name] is obj][0]


def make_boxplot(df, root_directory_results, title_name):
    # accepts a dataframe and returns the boxplot by column
    # saves a png file named as the dataframe

    fig = plt.figure(figsize=(20, 7))
    fig.suptitle('Algorithm comparison')
    ax = fig.add_subplot(111)
    plt.boxplot(df, patch_artist=True, showmeans=True)
    ax.set_xticklabels(df.columns)
    ax.set_ylim(0, 1.1)
    ax.set_xlim(auto=True)
    plt.title(title_name)
    plt.savefig(root_directory_results + '%s.png' % title_name)

# def grid_search_neighbors():
#     neighbors = [x for x in range(1, 12)]
#     # neighbors=[12,22]
#
#     for ele in neighbors:
#         results = []
#         names = []
#         methods = [
#             # ('ADASYN', ADASYN(random_state=32, sampling_strategy='minority',n_jobs=-1, n_neighbors=ele)),
#             ('SMOTE', SMOTE(random_state=32, sampling_strategy='minority', n_jobs=-1, k_neighbors=ele))]
#
#         for sampling_name, method in methods:
#
#             for model_name, model in models_list:
#                 piped_model = make_pipeline(Normalizer(), method, model)
#                 cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=1)
#                 scores = cross_val_score(piped_model, kbest_data_x, y, scoring='balanced_accuracy',
#                                          cv=cv, n_jobs=-1, error_score='raise')
#                 results.append(scores)
#                 names.append(sampling_name + "-" + model_name)
#                 print("%d / %s / %s: %0.3f +/- %0.3f" % (ele, sampling_name, model_name, scores.mean(), scores.std()))
