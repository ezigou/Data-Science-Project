from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier, AdaBoostClassifier
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import balanced_accuracy_score, make_scorer

from imblearn.over_sampling import RandomOverSampler, SMOTE, ADASYN, BorderlineSMOTE
from imblearn.combine import SMOTETomek, SMOTEENN
from imblearn.under_sampling import RandomUnderSampler, ClusterCentroids, NearMiss
from imblearn.under_sampling import RepeatedEditedNearestNeighbours, TomekLinks
from imblearn.metrics import specificity_score, sensitivity_score
from imblearn.ensemble import BalancedBaggingClassifier, BalancedRandomForestClassifier
from imblearn.ensemble import RUSBoostClassifier, EasyEnsembleClassifier
from xgboost import XGBClassifier


# create a list (of tuples) of the ML models
models_list = [('LR', LogisticRegression(solver='liblinear')),
               ('CART', DecisionTreeClassifier(random_state=25)),
               ('RFC', RandomForestClassifier(random_state=25)),
               ('KNN', KNeighborsClassifier()),
               ('SVC', SVC()),
               ('LnSVC', LinearSVC())
               ]

# create a dictionary of evaluation metrics
metrics_dict = {'balanced_accuracy': make_scorer(balanced_accuracy_score),
                'sensitivity': make_scorer(sensitivity_score),
                'specificity': make_scorer(specificity_score)}

# create a list (of tuples) of sampling methods
sampling_list = [('RanOver', RandomOverSampler(random_state=32, sampling_strategy='minority')),
                 ('ADASYN', ADASYN(random_state=32, sampling_strategy='minority', n_neighbors=5, n_jobs=-1)),
                 ('SMOTE', SMOTE(random_state=32, sampling_strategy='minority', k_neighbors=5, n_jobs=-1)),
                 ('BLSmote', BorderlineSMOTE(random_state=32, sampling_strategy='minority', k_neighbors=5,
                                             m_neighbors=10, kind='borderline-1', n_jobs=-1)),
                 ('SmoteTom', SMOTETomek(random_state=32, sampling_strategy='minority', n_jobs=-1)),
                 ('SmoteENN', SMOTEENN(random_state=32, sampling_strategy='minority', n_jobs=-1)),
                 ('RanUnder', RandomUnderSampler(random_state=32, sampling_strategy='majority', replacement=False)),
                 ('ClustCen', ClusterCentroids(random_state=32, sampling_strategy='majority', n_jobs=-1)),
                 ('NearMiss', NearMiss(version=3, sampling_strategy='majority', n_jobs=-1)),
                 ('TomLinks', TomekLinks(sampling_strategy='majority', n_jobs=-1)),
                 ('RepENN', RepeatedEditedNearestNeighbours(sampling_strategy='majority', n_jobs=-1))
                 ]

# create a list of tuples of ensembles methods:
ensembles_list = [('RFbw', RandomForestClassifier(random_state=25, n_estimators=100, class_weight='balanced_subsample',
                                                  n_jobs=-1)),
                  ('AdaBoost', AdaBoostClassifier(base_estimator=DecisionTreeClassifier(random_state=25),
                                                  random_state=66, n_estimators=100)),
                  ('GB', GradientBoostingClassifier(random_state=66, n_estimators=100, loss='deviance')),
                  ('XGB', XGBClassifier(validate_parameters='balanced_accuracy', random_state=66, scale_pos_weights=30,
                                        n_estimators=100, n_jobs=-1, verbosity=0)),
                  ('BB', BalancedBaggingClassifier(base_estimator=DecisionTreeClassifier(random_state=25),
                                                   random_state=66, n_estimators=100, n_jobs=-1)),
                  ('BBada', BalancedBaggingClassifier(base_estimator=AdaBoostClassifier(), random_state=66,
                                                      n_estimators=100, n_jobs=-1)),
                  ('BRF', BalancedRandomForestClassifier(random_state=66, n_estimators=100, replacement=True,
                                                         n_jobs=-1)),
                  ('RUSBoost', RUSBoostClassifier(base_estimator=AdaBoostClassifier(), random_state=66,
                                                  n_estimators=100, replacement=False)),
                  ('EE', EasyEnsembleClassifier(random_state=66, n_estimators=100, n_jobs=-1))
                  ]

