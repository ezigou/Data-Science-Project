import configparser
import os

from json import loads


class GetConfig:
    def __init__(self, id_topic='generic'):
        # set a config var of type config parser
        config = configparser.ConfigParser()
        # get the root directory that config.ini exists
        self.base_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)))
        # get full path of config.ini
        root = os.path.join(self.base_dir, "config.ini")
        # read ini file
        config.read(root)
        # return contents of id_topic in key, value format
        self.config = config[id_topic]

    def get_config(self, param):
        return self.config.get(param)

    def get_config_str(self, param):
        return str(self.get_config(param))

    def get_config_int(self, param):
        return int(self.get_config(param))

    def get_config_float(self, param):
        return float(self.get_config(param))

    def get_config_bool(self, param):
        return self.config.getboolean(param)

    def get_config_list(self, param):
        return loads(self.get_config(param))