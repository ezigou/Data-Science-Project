# official libs imports
import pandas as pd
import warnings
import time

# official libs from
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier

# project custom functions import
from src.configuration_parser import GetConfig
from src.custom_functions import balance_percentage, filter_constant_columns, calculate_correlations, \
    calculate_skewness, delete_correlated_features, evaluate_model_rfe, evaluate_model_etc, evaluate_model_kbest,\
    kbest_2, evaluate_models_imbalanced, evaluate_models_balanced, make_boxplot, helper_name_str

from src.models_lists import models_list, ensembles_list, metrics_dict, sampling_list

# ignore warnings
warnings.filterwarnings("ignore")

if __name__ == "__main__":
    """RUN"""

    # measure the time for data loading and preparation
    print("project starts")
    data_start = time.perf_counter()

    """Data loading"""

    # create configuration object
    configuration = GetConfig()

    # load the csv data file (pandas dataframe)
    data_src_path = configuration.get_config_str('data_read_path')
    data = pd.read_csv(data_src_path)

    # set the result directory
    root_directory_results = configuration.get_config_str('root_directory_results')

    # get flags based on which features to run or not
    flag_feature_selections = configuration.get_config_bool('flag_feature_selections')
    flag_sampling = configuration.get_config_bool('flag_sampling')
    flag_ensembles = configuration.get_config_bool('flag_ensembles')

    print("original data shape: " + str(data.shape))

    # calculate balance percentage and visualise it
    balance_percentage(data, "Bankrupt?", root_directory_results=root_directory_results)

    # rearrange the data so target variable is in the last column
    cols = [col for col in data if col != data.columns[0]] + [data.columns[0]]
    data = data[cols]

    # delete constant columns
    data = filter_constant_columns(data)
    print("new data shape: " + str(data.shape))

    # rename columns for convenience

    # new names
    numbered_names = ["X" + str(i) for i in range(0, 95)]
    # create a dictionary that stores the matching
    attributes_matching = dict(zip(numbered_names, data.columns))
    # export the dictionary to a csv file
    with open(root_directory_results + 'numbered_names.csv', 'w') as f:
        for key in attributes_matching.keys():
            f.write("%s,%s\n" % (key, attributes_matching[key]))
    # rename the columns of the dataset
    data.columns = numbered_names

    """Descriptive Statistics"""

    # examine the data types
    data.dtypes.to_csv(root_directory_results + "types.csv")

    # variable description
    description = data.describe()
    description = description.applymap(lambda x_value: round(float(x_value), 3))
    description.to_csv(root_directory_results + "description.csv")
    print(description)

    # examine variable skewness
    calculate_skewness(data, root_directory_results=root_directory_results)

    """Handling with correlations"""

    # examine variable correlations
    print("From the maximum correlated features table")
    correlations = calculate_correlations(
        df_data_set=data, root_directory_results=root_directory_results, numbered_names=numbered_names)

    # visualise correlated features
    # correlation_plot(correlations)

    # remove from the data the highly correlated features (above 0.8)

    data = delete_correlated_features(data=data, correlation_matrix=correlations)
    print("Features kept to the dataset:")
    print(data.columns)
    print(data.shape)

    # save the transformed data to csv file
    data.to_csv(root_directory_results + "uncorrelated_data.csv")
    # save to a txt file the features retained after removing the highly correlated
    uncorrelated = data.columns.to_list()
    with open(root_directory_results + "uncorrelated_features.txt", 'w') as w_f:
        for element in uncorrelated:
            w_f.write(element + "\n")

    # split data to features (x) and target (y) dataframes
    x = data.drop(columns='X94')
    y = data['X94']

    # measure the time for data loading and preparation
    data_end = time.perf_counter()

    if flag_feature_selections:
        """Feature Selection Processes"""

        # measure the time for feature selection processes
        fs_start = time.perf_counter()

        """RFE"""

        print("RFE - LR:")
        evaluate_model_rfe(LogisticRegression(solver='liblinear'), x, y, 30)

        print("RFE - CART:")
        evaluate_model_rfe(DecisionTreeClassifier(random_state=25), x, y, 30)

        print("RFE - RFC:")
        evaluate_model_rfe(RandomForestClassifier(random_state=25), x, y, 30)

        print("RFE - LnSVC:")
        evaluate_model_rfe(LinearSVC(), x, y, 30)

        # measure the time for RFE process
        rfe_end = time.perf_counter()

        """ETC"""

        print("ETC - LR:")
        evaluate_model_etc(LogisticRegression(solver='liblinear'), x, y, 30, root_directory_results)
        print("ETC - CART:")
        evaluate_model_etc(DecisionTreeClassifier(random_state=25), x, y, 30, root_directory_results)
        print("ETC - RFC:")
        evaluate_model_etc(RandomForestClassifier(random_state=25), x, y, 30, root_directory_results)
        print("ETC - KNN:")
        evaluate_model_etc(KNeighborsClassifier(), x, y, 30, root_directory_results)
        print("ETC - SVC:")
        evaluate_model_etc(SVC(), x, y, 30, root_directory_results)
        print("ETC - LnSVC:")
        evaluate_model_etc(LinearSVC(), x, y, 30, root_directory_results)

        # measure the time for ETC process
        etc_end = time.perf_counter()

        """KBEST"""

        print("KBEST - LR:")
        evaluate_model_kbest(LogisticRegression(solver='liblinear'), x, y, 30, root_directory_results)
        print("KBEST - CART:")
        evaluate_model_kbest(DecisionTreeClassifier(random_state=25), x, y, 30, root_directory_results)
        print("KBEST - RFC:")
        evaluate_model_kbest(RandomForestClassifier(random_state=25), x, y, 30, root_directory_results)
        print("KBEST - KNN:")
        evaluate_model_kbest(KNeighborsClassifier(), x, y, 30, root_directory_results)
        print("KBEST - SVC:")
        evaluate_model_kbest(SVC(), x, y, 30, root_directory_results)
        print("KBEST - LnSVC:")
        evaluate_model_kbest(LinearSVC(), x, y, 30, root_directory_results)

        # measure the time for KBEST process
        # measure the time for feature selection processes
        fs_end = time.perf_counter()

    """FINAL DECISION ON FEATURE SELECTION"""

    # TRANSFORM THE DATASET WITH K-BEST METHOD
    # DECIDED NUMBER OF FEATURES EQUAL TO 4

    # measure the time for data loading and preparation
    data_start_2 = time.perf_counter()

    # kbest_norm_data_x = kbest(x, y, 4)  # normalised
    kbest_data_x = kbest_2(x, y, 4)  # not normalised

    # measure the time for data loading and preparation
    data_end_2 = time.perf_counter()

    """CREATION OF STRUCTURES CONTAINING THE APPLIED ALGORITHMS/METHODOLOGIES"""

    if flag_sampling:
        """APPLYING SAMPLING METHODS"""

        # measure the time for sampling processes
        sampling_start = time.perf_counter()

        # evaluate the ML models for imbalanced and normalized selected features
        evaluate_models_imbalanced(
            given_list=models_list,
            models_list=models_list,
            root_directory_results=root_directory_results,
            metrics_dict=metrics_dict,
            kbest_data_x=kbest_data_x,
            y=y
        )

        # evaluate the ML models on balanced and normalized selected features
        evaluate_models_balanced(
            models_list=models_list,
            sampling_list=sampling_list,
            root_directory_results=root_directory_results,
            metrics_dict=metrics_dict,
            kbest_data_x=kbest_data_x,
            y=y
        )

        # Create tables of mean values and standard deviations of evaluation metrics
        # for every sampling method used (or none) for each model

        imbalanced_mean_values = pd.read_csv(root_directory_results + "imbalanced_mean_values.csv")
        balanced_mean_values = pd.read_csv(root_directory_results + "balanced_mean_values.csv")

        # create new dataframes of mean values and standard deviations of evaluation metrics
        # per ML model for every sampling method (and none)

        # specify the interval for concatenation
        interval = len(sampling_list)

        matrix_LR = pd.concat([imbalanced_mean_values["LR"], balanced_mean_values.iloc[:, 1:1+interval]], axis=1)
        matrix_CART = pd.concat([imbalanced_mean_values["CART"], balanced_mean_values.iloc[:, 1+interval:1+2*interval]], axis=1)
        matrix_RFC = pd.concat([imbalanced_mean_values["RFC"], balanced_mean_values.iloc[:, 1+2*interval:1+3*interval]], axis=1)
        matrix_KNN = pd.concat([imbalanced_mean_values["KNN"], balanced_mean_values.iloc[:, 1+3*interval:1+4*interval]], axis=1)
        matrix_SVC = pd.concat([imbalanced_mean_values["SVC"], balanced_mean_values.iloc[:, 1+4*interval:1+5*interval]], axis=1)
        matrix_LnSVC = pd.concat([imbalanced_mean_values["LnSVC"], balanced_mean_values.iloc[:, 1+5*interval:1+6*interval]], axis=1)

        matrix_LR.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                           "train spec"]
        matrix_CART.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                             "train spec"]
        matrix_RFC.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                            "train spec"]
        matrix_KNN.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                            "train spec"]
        matrix_SVC.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                            "train spec"]
        matrix_LnSVC.index = ["fit time", "score time", "test BA", "train BA", "test sens", "train sens", "test spec",
                              "train spec"]

        # store to csv
        matrix_LR.to_csv(root_directory_results + "matrix_LR.csv")
        matrix_CART.to_csv(root_directory_results + "matrix_CART.csv")
        matrix_RFC.to_csv(root_directory_results + "matrix_RFC.csv")
        matrix_KNN.to_csv(root_directory_results + "matrix_KNN.csv")
        matrix_SVC.to_csv(root_directory_results + "matrix_SVC.csv")
        matrix_LnSVC.to_csv(root_directory_results + "matrix_LnSVC.csv")

        # Make dataframes to create boxplots for every sampling method used (or none) for each model

        # load and read the files that store the metrics
        bal_acc_1 = pd.read_csv(root_directory_results + "imbalanced_scores_bal_acc.csv")
        bal_acc_1 = bal_acc_1.drop(['Unnamed: 0'], axis=1)
        bal_acc_2 = pd.read_csv(root_directory_results + "balanced_scores_bal_acc.csv")

        sensitivity_1 = pd.read_csv(root_directory_results + "imbalanced_scores_sensitivity.csv")
        sensitivity_1 = sensitivity_1.drop(['Unnamed: 0'], axis=1)
        sensitivity_2 = pd.read_csv(root_directory_results + "balanced_scores_sensitivity.csv")

        specificity_1 = pd.read_csv(root_directory_results + "imbalanced_scores_specificity.csv")
        specificity_1 = specificity_1.drop(['Unnamed: 0'], axis=1)
        specificity_2 = pd.read_csv(root_directory_results + "balanced_scores_specificity.csv")

        # create new dataframes of evaluation metrics per ML model
        # for every sampling method (and none)

        # balanced accuracy
        acc_matrix_LR = pd.concat([bal_acc_1["LR"], bal_acc_2.iloc[:, 1:1+interval]], axis=1)
        acc_matrix_CART = pd.concat([bal_acc_1["CART"], bal_acc_2.iloc[:, 1+interval:1+2*interval]], axis=1)
        acc_matrix_RFC = pd.concat([bal_acc_1["RFC"], bal_acc_2.iloc[:, 1+2*interval:1+3*interval]], axis=1)
        acc_matrix_KNN = pd.concat([bal_acc_1["KNN"], bal_acc_2.iloc[:, 1+3*interval:1+4*interval]], axis=1)
        acc_matrix_SVC = pd.concat([bal_acc_1["SVC"], bal_acc_2.iloc[:, 1+4*interval:1+5*interval]], axis=1)
        acc_matrix_LnSVC = pd.concat([bal_acc_1["LnSVC"], bal_acc_2.iloc[:, 1+5*interval:1+6*interval]], axis=1)

        # sensitivity
        sensitivity_matrix_LR = pd.concat([sensitivity_1["LR"], sensitivity_2.iloc[:, 1:1+interval]], axis=1)
        sensitivity_matrix_CART = pd.concat([sensitivity_1["CART"], sensitivity_2.iloc[:, 1+interval:1+2*interval]], axis=1)
        sensitivity_matrix_RFC = pd.concat([sensitivity_1["RFC"], sensitivity_2.iloc[:, 1+2*interval:1+3*interval]], axis=1)
        sensitivity_matrix_KNN = pd.concat([sensitivity_1["KNN"], sensitivity_2.iloc[:, 1+3*interval:1+4*interval]], axis=1)
        sensitivity_matrix_SVC = pd.concat([sensitivity_1["SVC"], sensitivity_2.iloc[:, 1+4*interval:1+5*interval]], axis=1)
        sensitivity_matrix_LnSVC = pd.concat([sensitivity_1["LnSVC"], sensitivity_2.iloc[:, 56:67]], axis=1)

        # specificity
        specificity_matrix_LR = pd.concat([specificity_1["LR"], specificity_2.iloc[:, 1:1+interval]], axis=1)
        specificity_matrix_CART = pd.concat([specificity_1["CART"], specificity_2.iloc[:, 1+interval:1+2*interval]], axis=1)
        specificity_matrix_RFC = pd.concat([specificity_1["RFC"], specificity_2.iloc[:, 1+2*interval:1+3*interval]], axis=1)
        specificity_matrix_KNN = pd.concat([specificity_1["KNN"], specificity_2.iloc[:, 1+3*interval:1+4*interval]], axis=1)
        specificity_matrix_SVC = pd.concat([specificity_1["SVC"], specificity_2.iloc[:, 1+4*interval:1+5*interval]], axis=1)
        specificity_matrix_LnSVC = pd.concat([specificity_1["LnSVC"], specificity_2.iloc[:, 1+5*interval:1+6*interval]], axis=1)

        # make and store the boxplots to evaluate classification models and sampling methods

        # make a list of the matrices that will be used for boxploting
        boxplot_list = [bal_acc_1, sensitivity_1, specificity_1, acc_matrix_LR, acc_matrix_CART, acc_matrix_RFC,
                        acc_matrix_KNN, acc_matrix_SVC, acc_matrix_LnSVC, sensitivity_matrix_LR,
                        sensitivity_matrix_CART,
                        sensitivity_matrix_RFC, sensitivity_matrix_KNN, sensitivity_matrix_SVC,
                        sensitivity_matrix_LnSVC,
                        specificity_matrix_LR, specificity_matrix_CART, specificity_matrix_RFC, specificity_matrix_KNN,
                        specificity_matrix_SVC, specificity_matrix_LnSVC]

        for matrix in boxplot_list:
            title_name = helper_name_str(matrix, globals())
            make_boxplot(df=matrix, root_directory_results=root_directory_results, title_name=title_name)

        # measure the time for sampling processes
        sampling_end = time.perf_counter()

    if flag_ensembles:
        """APPLYING ENSEMBLE MODELS"""

        # measure the time for ensemble processes
        ensemble_start = time.perf_counter()

        # evaluate ensemble models for imbalanced and normalized selected features
        evaluate_models_imbalanced(
            given_list=ensembles_list,
            models_list=models_list,
            root_directory_results=root_directory_results,
            metrics_dict=metrics_dict,
            kbest_data_x=kbest_data_x,
            y=y
        )

        # Make dataframes to create boxplots for every ensemble model

        # load and read the files that store the metrics
        bal_acc_ens = pd.read_csv(root_directory_results + "ensemble_scores_bal_acc.csv")
        bal_acc_ens = bal_acc_ens.drop(['Unnamed: 0'], axis=1)

        sensitivity_ens = pd.read_csv(root_directory_results + "ensemble_scores_sensitivity.csv")
        sensitivity_ens = sensitivity_ens.drop(['Unnamed: 0'], axis=1)

        specificity_ens = pd.read_csv(root_directory_results + "ensemble_scores_specificity.csv")
        specificity_ens = specificity_ens.drop(['Unnamed: 0'], axis=1)

        # make and store the boxplots to evaluate ensemble models

        # make a list of the matrices that will be used for boxploting
        boxplot_list_ens = [bal_acc_ens, sensitivity_ens, specificity_ens]

        for metric in boxplot_list_ens:
            title_name = helper_name_str(metric, globals())
            make_boxplot(df=metric, root_directory_results=root_directory_results, title_name=title_name)

        # measure the time for ensemble processes
        ensemble_end = time.perf_counter()

    """REPORT THE TIME OF EACH PART"""

    # time to load and prepare the data
    data_time_1 = data_end - data_start
    data_time_2 = data_end_2 - data_start_2
    data_time = data_time_1 + data_time_2
    print("Total time for data loading and preparation: ", data_time, "seconds")

    if flag_feature_selections:
        # time to perform feature selections
        # RFE
        rfe_time = rfe_end - fs_start
        # ETC
        etc_time = etc_end - rfe_end
        # KBEST
        kbest_time = fs_end - etc_end
        print("Total time for RFE feature selection: ", rfe_time, "seconds", )
        print("Total time for ETC feature selection: ", etc_time, "seconds")
        print("Total time for KBEST feature selection: ", kbest_time, "seconds")

    if flag_sampling:
        # time to apply sampling methodologies
        sampling_time = sampling_end - sampling_start
        print("Total time for applying sampling methods: ", sampling_time, "seconds")

    if flag_ensembles:
        # time to apply ensemble models
        ensemble_time = ensemble_end - ensemble_start
        print("Total time for applying ensemble methods: ", ensemble_time, "seconds")

    print("project ends")
