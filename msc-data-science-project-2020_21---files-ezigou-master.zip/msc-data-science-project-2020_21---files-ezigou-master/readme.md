## **msc-data-science-project-2020_21---files-ezigou**

This is project is the dissertation code of Eirini Zygoura

### **Installation (Open Anaconda Prompt)**

This project uses conda package manager.

**Windows/Linux**

`conda env create --file project_dependencies.yml`

#### **Verify Installation**

`conda activate msc-data-science-project-2020_21---files-ezigou`